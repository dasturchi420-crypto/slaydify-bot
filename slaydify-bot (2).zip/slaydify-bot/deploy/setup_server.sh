#!/usr/bin/env bash
# Oracle serverda BIR MARTA ishga tushiriladi:  bash setup_server.sh
set -euo pipefail

APP_DIR="$HOME/slaydify-bot"
USER_NAME="$(whoami)"

sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip rsync

mkdir -p "$APP_DIR"
cd "$APP_DIR"
python3 -m venv venv

# .env bo'lmasa shablon yaratamiz
if [ ! -f .env ]; then
cat > .env <<'ENVEOF'
BOT_TOKEN=
AI_PROVIDER=gemini
GEMINI_API_KEY=
GROQ_API_KEY=
ANTHROPIC_API_KEY=
FREE_CREDITS=3
MAX_PARALLEL=3
ADMIN_IDS=
ENVEOF
chmod 600 .env
echo ">>> $APP_DIR/.env faylini to'ldiring: nano $APP_DIR/.env"
fi

sudo tee /etc/systemd/system/slaydify.service >/dev/null <<SERVICE
[Unit]
Description=Slaydify Telegram bot
After=network-online.target
Wants=network-online.target

[Service]
User=$USER_NAME
WorkingDirectory=$APP_DIR
ExecStart=$APP_DIR/venv/bin/python bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

sudo systemctl daemon-reload
sudo systemctl enable slaydify
echo ">>> Tayyor. Birinchi deploy'dan keyin bot o'zi ishga tushadi."
echo ">>> Loglar: sudo journalctl -u slaydify -f"
